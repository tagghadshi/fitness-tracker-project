package com.appointment;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AppointmentApplicationTests {

	@Test
	void contextLoads() {
	}

}
